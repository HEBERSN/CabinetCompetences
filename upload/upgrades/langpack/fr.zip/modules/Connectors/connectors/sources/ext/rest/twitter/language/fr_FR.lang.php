<?php

    if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

    $connector_strings = array (
        //Vardef labels
        'LBL_LICENSING_INFO' => '<table border="0" cellspacing="1"><tr><th valign="top" width="35%" class="dataLabel">Twitter Application Information </th></tr>
                                    <tr><td width="35%" class="dataLabel">You will need to create a Twitter Developer account and Application <a href=https://dev.twitter.com/> Sign Up</a></td></tr></table>',
        //Configuration labels
        'consumer_key' => 'OAuth Consumer Key',
        'consumer_secret' => 'OAuth Consumer Secret',
    );


?>
